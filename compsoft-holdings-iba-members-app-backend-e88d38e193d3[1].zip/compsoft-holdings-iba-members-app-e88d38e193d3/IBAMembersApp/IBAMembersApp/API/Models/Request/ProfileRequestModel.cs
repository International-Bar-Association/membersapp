﻿namespace IBAMembersApp.API.Models.Request
{
    public class ProfileRequestModel
    {
        public string Biography { get; set; }
    }
}
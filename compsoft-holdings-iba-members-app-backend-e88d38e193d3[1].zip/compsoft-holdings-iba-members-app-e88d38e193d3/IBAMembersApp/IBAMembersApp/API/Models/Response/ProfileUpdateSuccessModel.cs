﻿namespace IBAMembersApp.API.Models.Response
{
    public class ProfileUpdateSuccessModel:BaseResponseModel
    {

    }
}

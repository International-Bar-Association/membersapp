﻿namespace IBAMembersApp.BusinessLayer.Models
{
    public class ContentLibraryRequestModel
    {
        public int Start { get; set; }
        public int Length { get; set; }
    }
}
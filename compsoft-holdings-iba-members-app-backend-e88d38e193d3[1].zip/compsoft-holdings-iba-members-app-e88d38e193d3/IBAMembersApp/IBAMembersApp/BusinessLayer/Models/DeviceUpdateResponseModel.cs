﻿namespace IBAMembersApp.BusinessLayer.Models
{
    public class DeviceUpdateResponseModel :BaseV2ResponseModel
    {
    }
}
﻿namespace IBAMembersApp.Models
{
    public class CsvRecipientModel
    {
        // ReSharper disable once InconsistentNaming
        public decimal id { get; set; }
        // ReSharper disable once InconsistentNaming
        public string given_name { get; set; }
        // ReSharper disable once InconsistentNaming
        public string family_name { get; set; }
    }
}